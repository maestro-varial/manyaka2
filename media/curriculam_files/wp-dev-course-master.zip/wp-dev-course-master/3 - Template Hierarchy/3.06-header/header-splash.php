<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <?php wp_head(); ?>
  </head>
  <body>
    <div class="notice">
      <p>NEW - Lorem to the sell thisum!</p>
    </div>
