<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHP for WordPress</title>
  <?php wp_head(); ?>
</head>
<body class="<?php body_class(); ?>">

  <header id="masthead">
    <h1><a href="#">PHP for WordPress</a></h1>
  </header>
